

typedef unsigned char IP_t[4];
